
import joblib
import pandas as pd

model = joblib.load('model/patient_risk_model.pkl')

def predict_risk(input_data: dict):
    df = pd.DataFrame([input_data])
    prob = model.predict_proba(df)[0][1]
    category = 'High' if prob > 0.7 else 'Medium' if prob > 0.4 else 'Low'
    return {'risk_score': round(float(prob), 3), 'risk_category': category}
