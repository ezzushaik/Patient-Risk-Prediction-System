
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score
from xgboost import XGBClassifier
import joblib

# Sample placeholder data
data = pd.DataFrame({
    'age': [45, 67, 52, 39, 76, 63],
    'bmi': [24.3, 29.8, 27.1, 22.5, 31.2, 28.0],
    'heart_rate': [88, 102, 95, 80, 110, 98],
    'blood_pressure': [120, 145, 135, 118, 160, 140],
    'glucose': [90, 120, 110, 85, 140, 115],
    'readmit': [0, 1, 0, 0, 1, 1]
})

X = data.drop('readmit', axis=1)
y = data['readmit']

X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)
model = XGBClassifier(max_depth=6, n_estimators=50, learning_rate=0.1)
model.fit(X_train, y_train)
preds = model.predict_proba(X_val)[:, 1]
auc = roc_auc_score(y_val, preds)
print(f"Validation AUC: {auc:.3f}")

joblib.dump(model, 'model/patient_risk_model.pkl')
print('Model saved successfully.')
